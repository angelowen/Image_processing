
%% start
clear all;
close all;
A = imread('images/aloe.jpg');
A1 = imread('images/church.jpg');
A2 = imread('images/house.jpg');
A3 = imread('images/kitchen.jpg');
enhancement(A,1);
enhancement(A1,2);
enhancement(A2,3);
enhancement(A3,4);
%% main
function []= enhancement(pic,num)
    Adoub = im2double(pic);
    %RGB
    [R,G,B] = imsplit(Adoub);
    Rsharpened = adapthisteq(R);
    Gsharpened = adapthisteq(G);
    Bsharpened = adapthisteq(B);
    rgbImage = cat(3, Rsharpened,Gsharpened,Bsharpened);

    %HSI
    [H,S,I]= rgb2hsi(pic);
    I = adapthisteq(I);%histeq
    S = adapthisteq(S);
    P = hsi2rgb(H,S,I);

    %L*a*b*
    A2 = rgb2lab(pic);
    max_luminosity = 100;
    L = A2(:,:,1)/max_luminosity;
    po = A2;
    po(:,:,1) = adapthisteq(L)*max_luminosity;
    po = lab2rgb(po);
    
    figure(num),
    subplot(2,2,1);imshow(pic); title('Original image');
    subplot(2,2,2);imshow(rgbImage); title('RGB hist');
    subplot(2,2,3);imshow(P); title('HSI result');
    subplot(2,2,4);imshow(po); title('L*a*b* histeq');
end
%% hsi to rgb
function rgb = hsi2rgb(H,S,I)
    hsi = cat(3, H, S, I);
    % Extract the individual HSI component images. 
    H=hsi(:,:,1)*2*pi;
    S=hsi(:,:,2);
    I=hsi(:,:,3);
    R=zeros(size(hsi,1),size(hsi,2));
    G=zeros(size(hsi,1),size(hsi,2));
    B=zeros(size(hsi,1),size(hsi,2));
    idx=find((0<=H)&(H<2*pi/3));
    B(idx)=I(idx).*(1-S(idx));
    R(idx)=I(idx).*(1+S(idx).*cos(H(idx))./cos(pi/3-H(idx)));
    G(idx)=3*I(idx)-(R(idx)+B(idx));
    idx=find((2*pi/3<=H)&(H<4*pi/3));
    R(idx)=I(idx).*(1-S(idx));
    G(idx)=I(idx).*(1+S(idx).*cos(H(idx)-2*pi/3)./cos(pi-H(idx)));
    B(idx)=3*I(idx)-(R(idx)+G(idx));
    idx=find((4*pi/3<=H)&(H<=2*pi));
    G(idx)=I(idx).*(1-S(idx));
    B(idx)=I(idx).*(1+S(idx).*cos(H(idx)-4*pi/3)./cos(5*pi/3-H(idx)));
    R(idx)=3*I(idx)-(G(idx)+B(idx));
    rgb=cat(3,R,G,B);
    rgb=max(min(rgb,1),0);
end

%% rgb to hsi
function [H,S,I] = rgb2hsi(rgb) 
    rgb = im2double(rgb);  
    r = rgb(:, :, 1);  
    g = rgb(:, :, 2);  
    b = rgb(:, :, 3);    
    num = 0.5*((r - g) + (r - b));  
    den = sqrt((r - g).^2 + (r - b).*(g - b));  
    theta = acos(num./(den + eps)); %�����=0   
    H = theta;  
    H(b > g) = 2*pi - H(b > g);  
    H = H/(2*pi);    
    num = min(min(r, g), b);  
    den = r + g + b;  
    den(den == 0) = eps; %�����=0  
    S = 1 - 3.* num./den;  
    H(S == 0) = 0;  
    I = (r + g + b)/3; 
    % Combine all three results into an hsi image. 
end
